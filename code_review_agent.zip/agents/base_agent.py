import os
import openai

class BaseAgent:
    def __init__(self, model="gpt-4", temperature=0):
        openai.api_key = os.getenv("OPENAI_API_KEY")
        self.model = model
        self.temperature = temperature

    def query_llm(self, prompt: str) -> str:
        import json
        response = openai.ChatCompletion.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=self.temperature,
        )
        return response.choices[0].message.content
