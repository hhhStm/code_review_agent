# 代码自动审查 Agent

## 功能
- 多 Agent 协作：性能、安全、风格检查
- 批量扫描 Python 文件
- 生成 HTML 审查报告

## 使用
1. 安装依赖
   pip install -r requirements.txt
2. 设置 OpenAI API Key
   export OPENAI_API_KEY="你的API_KEY"
3. 运行主程序
   python main.py
