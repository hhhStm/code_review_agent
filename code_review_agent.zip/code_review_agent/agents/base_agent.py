import os
from openai import OpenAI

class BaseAgent:
    def __init__(self, model="deepseek-v4-pro", temperature=0):
        self.client = OpenAI(
            api_key="sk-01fac9a4c434497cb57986b246ed68bd",
            base_url="https://api.deepseek.com",
        )
        self.model = model
        self.temperature = temperature

    def query_llm(self, prompt: str) -> str:
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=self.temperature,
        )
        return response.choices[0].message.content
