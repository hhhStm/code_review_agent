from .base_agent import BaseAgent

class PerformanceAgent(BaseAgent):
    def review(self, code: str) -> str:
        prompt = f"""
        你是性能优化专家，请检查以下 Python 代码的性能问题，并给出改进建议：
        {code}
        返回 JSON 格式：{{"issues": [{{"line": 行号, "description": "问题描述"}}]}}
        """
        return self.query_llm(prompt)
