from .base_agent import BaseAgent

class StyleAgent(BaseAgent):
    def review(self, code: str) -> str:
        prompt = f"""
        你是代码风格专家，请检查以下 Python 代码的可读性和规范性，并给出改进建议：
        {code}
        返回 JSON 格式：{{"issues": [{"line": 行号, "description": "问题描述"}]}}
        """
        return self.query_llm(prompt)
