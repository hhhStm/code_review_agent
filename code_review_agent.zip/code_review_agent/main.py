import os
import json
from agents.performance_agent import PerformanceAgent
from agents.security_agent import SecurityAgent
from agents.style_agent import StyleAgent
from utils import list_python_files, save_html_report

def generate_report(code_files, agents, report_path="reports/report.html"):
    all_results = {}
    for file in code_files:
        with open(file, "r", encoding="utf-8") as f:
            code = f.read()
        file_result = {}
        for agent in agents:
            review = agent.review(code)
            file_result[agent.__class__.__name__] = json.loads(review)
        all_results[file] = file_result

    html_content = "<html><body>"
    for file, result in all_results.items():
        html_content += f"<h2>{file}</h2>"
        for agent_name, issues in result.items():
            html_content += f"<h3>{agent_name}</h3>"
            html_content += "<ul>"
            for issue in issues.get("issues", []):
                html_content += f"<li>Line {issue['line']}: {issue['description']}</li>"
            html_content += "</ul>"
    html_content += "</body></html>"

    save_html_report(html_content, report_path)
    print(f"报告已生成: {report_path}")

if __name__ == "__main__":
    project_dir = "./"  # 扫描当前目录
    files = list_python_files(project_dir)
    agents = [PerformanceAgent(), SecurityAgent(), StyleAgent()]
    os.makedirs("reports", exist_ok=True)
    generate_report(files, agents)
