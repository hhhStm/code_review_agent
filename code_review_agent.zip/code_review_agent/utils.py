import os
import json
from typing import List

def list_python_files(root_dir: str) -> List[str]:
    py_files = []
    for dirpath, _, filenames in os.walk(root_dir):
        for f in filenames:
            if f.endswith(".py"):
                py_files.append(os.path.join(dirpath, f))
    return py_files

def save_html_report(report_content: str, path: str):
    with open(path, "w", encoding="utf-8") as f:
        f.write(report_content)
